var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_config = require("dotenv/config");
var import_express = __toESM(require("express"), 1);
var import_path3 = __toESM(require("path"), 1);
var import_fs3 = __toESM(require("fs"), 1);
var import_vite = require("vite");

// src/server/db.ts
var import_promise = __toESM(require("mysql2/promise"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var pool = null;
var dbInitialized = false;
var DB_CONFIG = {
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "yogo_simpak",
  password: process.env.DB_PASSWORD || "adminkcd13!!",
  database: process.env.DB_NAME || "yogo_simpak"
};
function getDbPool() {
  if (!pool) {
    pool = import_promise.default.createPool({
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      user: DB_CONFIG.user,
      password: DB_CONFIG.password,
      database: DB_CONFIG.database,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      enableKeepAlive: true,
      keepAliveInitialDelay: 1e4,
      connectTimeout: 2e3
    });
  }
  return pool;
}
async function autoInitializeMysql() {
  if (dbInitialized) return true;
  try {
    try {
      const rootConnection = await import_promise.default.createConnection({
        host: DB_CONFIG.host,
        port: DB_CONFIG.port,
        user: DB_CONFIG.user,
        password: DB_CONFIG.password,
        connectTimeout: 2e3
      });
      await rootConnection.query(
        `CREATE DATABASE IF NOT EXISTS \`${DB_CONFIG.database}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`
      );
      await rootConnection.end();
    } catch {
    }
    const p = getDbPool();
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`app_users\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`username\` VARCHAR(100) NOT NULL UNIQUE,
        \`password\` VARCHAR(255) NOT NULL,
        \`role\` ENUM('super_admin', 'school_admin') NOT NULL DEFAULT 'school_admin',
        \`school\` VARCHAR(255) NOT NULL DEFAULT 'ALL',
        \`displayName\` VARCHAR(255) NOT NULL,
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`schools\` (
        \`id\` VARCHAR(64) PRIMARY KEY,
        \`npsn\` VARCHAR(30) NOT NULL UNIQUE,
        \`name\` VARCHAR(255) NOT NULL,
        \`address\` TEXT NULL,
        \`city\` VARCHAR(100) NULL,
        \`principalName\` VARCHAR(255) NULL,
        \`principalNip\` VARCHAR(50) NULL,
        \`principalStatus\` ENUM('definitif', 'plt', 'plh') DEFAULT 'definitif',
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`teachers\` (
        \`id\` VARCHAR(64) PRIMARY KEY,
        \`name\` VARCHAR(255) NOT NULL,
        \`nip\` VARCHAR(50) NOT NULL,
        \`school\` VARCHAR(255) NOT NULL,
        \`currentGolongan\` VARCHAR(20) NOT NULL DEFAULT 'III/c',
        \`targetGolongan\` VARCHAR(20) NOT NULL DEFAULT 'III/d',
        \`baseAK\` DECIMAL(10, 3) DEFAULT 0.000,
        \`akIntegrasi2022\` DECIMAL(10, 3) DEFAULT 0.000,
        \`akPendidikan\` DECIMAL(10, 3) DEFAULT 0.000,
        \`ratingSKP\` VARCHAR(50) DEFAULT 'Baik',
        \`workDurationYears\` INT DEFAULT 0,
        \`karpegNumber\` VARCHAR(100) NULL,
        \`birthPlaceDate\` VARCHAR(255) NULL,
        \`gender\` ENUM('Laki-Laki', 'Perempuan') DEFAULT 'Laki-Laki',
        \`tmtCurrentPangkat\` VARCHAR(50) NULL,
        \`tmtCurrentJabatan\` VARCHAR(50) NULL,
        \`unitKerja\` VARCHAR(255) NULL,
        \`instansiBiro\` VARCHAR(255) NULL,
        \`nomorSuratKonversi\` VARCHAR(255) NULL,
        \`nomorSuratAkumulasi\` VARCHAR(255) NULL,
        \`nomorSuratPenetapan\` VARCHAR(255) NULL,
        \`tempatDitetapkan\` VARCHAR(100) NULL,
        \`tanggalPenetapan\` VARCHAR(100) NULL,
        \`pejabatPenilaiTitle\` VARCHAR(255) NULL,
        \`pejabatPenilaiInstansi\` VARCHAR(255) NULL,
        \`pejabatPenilaiNama\` VARCHAR(255) NULL,
        \`pejabatPenilaiNip\` VARCHAR(50) NULL,
        \`pejabatPenilaiGolongan\` VARCHAR(100) NULL,
        \`pejabatPenilaiStatus\` ENUM('definitif', 'plt', 'plh') DEFAULT 'definitif',
        \`signatureType\` VARCHAR(50) DEFAULT 'ttd_basah',
        \`ttdBasahType\` VARCHAR(50) DEFAULT 'blank',
        \`ttdBasahImageUrl\` TEXT NULL,
        \`ttdBasahImageBase64\` LONGTEXT NULL,
        \`ttdBasahHeight\` INT DEFAULT 64,
        \`tteLogoType\` VARCHAR(50) DEFAULT 'default',
        \`tteLogoUrl\` TEXT NULL,
        \`tteLogoBase64\` LONGTEXT NULL,
        \`tteTextHeader\` VARCHAR(255) DEFAULT 'Ditandatangani secara elektronik oleh :',
        \`tteTextJabatan1\` VARCHAR(255) NULL,
        \`tteTextJabatan2\` VARCHAR(255) NULL,
        \`skPangkatFileLink\` TEXT NULL,
        \`pakIntegrasiFileLink\` TEXT NULL,
        \`ijazahFileLink\` TEXT NULL,
        \`additionalFileLink\` TEXT NULL,
        \`createdBy\` VARCHAR(100) DEFAULT 'admin',
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`evaluations\` (
        \`id\` VARCHAR(64) PRIMARY KEY,
        \`teacherId\` VARCHAR(64) NOT NULL,
        \`year\` INT NOT NULL,
        \`period\` VARCHAR(100) DEFAULT 'Tahunan',
        \`rating\` VARCHAR(50) NOT NULL DEFAULT 'Baik',
        \`level\` VARCHAR(50) NOT NULL DEFAULT 'Ahli Muda',
        \`coefficient\` DECIMAL(10, 3) DEFAULT 25.000,
        \`multiplier\` DECIMAL(5, 2) DEFAULT 1.00,
        \`creditEarned\` DECIMAL(10, 3) DEFAULT 25.000,
        \`akPendidikan\` DECIMAL(10, 3) DEFAULT 0.000,
        \`notes\` TEXT NULL,
        \`startDate\` VARCHAR(50) NULL,
        \`endDate\` VARCHAR(50) NULL,
        \`isCustomRange\` TINYINT(1) DEFAULT 0,
        \`customMonths\` INT DEFAULT 12,
        \`skpFileLink\` TEXT NULL,
        \`evidenceFileLink\` TEXT NULL,
        \`overrideData\` LONGTEXT NULL,
        \`createdBy\` VARCHAR(100) DEFAULT 'admin',
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`kop_settings\` (
        \`id\` VARCHAR(32) PRIMARY KEY DEFAULT 'default',
        \`logoType\` VARCHAR(50) DEFAULT 'svg-jabar',
        \`customLogoUrl\` TEXT NULL,
        \`row1\` VARCHAR(255) DEFAULT 'PEMERINTAH DAERAH PROVINSI JAWA BARAT',
        \`row2\` VARCHAR(255) DEFAULT 'DINAS PENDIDIKAN',
        \`row3\` VARCHAR(255) DEFAULT 'CABANG DINAS PENDIDIKAN WILAYAH XIII',
        \`row4\` VARCHAR(255) DEFAULT 'Jalan Sukasenang No. 34 Telp./Fax (0265) 773123 Ciamis',
        \`row5\` VARCHAR(255) DEFAULT 'e-mail: cabdinwil13@gmail.com',
        \`row6\` VARCHAR(255) DEFAULT 'CIAMIS - 46211',
        \`signatureType\` VARCHAR(50) DEFAULT 'ttd_basah',
        \`ttdBasahType\` VARCHAR(50) DEFAULT 'blank',
        \`ttdBasahImageUrl\` TEXT NULL,
        \`ttdBasahImageBase64\` LONGTEXT NULL,
        \`ttdBasahHeight\` INT DEFAULT 64,
        \`tteLogoType\` VARCHAR(50) DEFAULT 'default',
        \`tteLogoUrl\` TEXT NULL,
        \`tteLogoBase64\` LONGTEXT NULL,
        \`tteTextHeader\` VARCHAR(255) DEFAULT 'Ditandatangani secara elektronik oleh :',
        \`tteTextJabatan1\` VARCHAR(255) DEFAULT 'KEPALA CABANG DINAS PENDIDIKAN WILAYAH XIII',
        \`tteTextJabatan2\` VARCHAR(255) DEFAULT 'DINAS PENDIDIKAN PROVINSI JAWA BARAT',
        \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    await p.query(`
      CREATE TABLE IF NOT EXISTS \`system_logs\` (
        \`id\` VARCHAR(64) PRIMARY KEY,
        \`timestamp\` VARCHAR(50) NOT NULL,
        \`error\` TEXT NOT NULL,
        \`operationType\` VARCHAR(50) DEFAULT 'general',
        \`path\` TEXT NULL,
        \`userId\` VARCHAR(100) NULL,
        \`email\` VARCHAR(100) NULL,
        \`browser\` TEXT NULL,
        \`severity\` ENUM('info', 'warning', 'error', 'critical') DEFAULT 'info',
        \`resolved\` TINYINT(1) DEFAULT 0,
        \`resolutionNotes\` TEXT NULL,
        \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    const [userCount] = await p.query("SELECT COUNT(*) as count FROM `app_users`");
    if (userCount[0].count === 0) {
      await p.query(`
        INSERT INTO \`app_users\` (username, password, role, school, displayName) VALUES
        ('admin', 'adminpaskonversi', 'super_admin', 'ALL', 'Super Admin Dinas Pendidikan KCD XIII'),
        ('admin123', 'admin123', 'super_admin', 'ALL', 'Admin Utama'),
        ('sman2ciamis', 'sman2ciamis123', 'school_admin', 'SMAN 2 CIAMIS', 'Operator SMAN 2 Ciamis'),
        ('sman1ciamis', 'sman1ciamis123', 'school_admin', 'SMAN 1 CIAMIS', 'Operator SMAN 1 Ciamis')
      `);
      console.log("Seeded initial app_users in MySQL.");
    }
    const [schoolCount] = await p.query("SELECT COUNT(*) as count FROM `schools`");
    if (schoolCount[0].count === 0) {
      await p.query(`
        INSERT INTO \`schools\` (id, npsn, name, city, address, principalName, principalNip, principalStatus) VALUES
        ('20211516', '20211516', 'SMAN 1 CIAMIS', 'Kabupaten Ciamis', 'Jl. Gunung Galunggung No. 37 Ciamis', 'Drs. H. Suarman Marks, M.Pd.', '196504121990031008', 'definitif'),
        ('20211517', '20211517', 'SMAN 2 CIAMIS', 'Kabupaten Ciamis', 'Jl. K.H. Ahmad Dahlan No. 2 Ciamis', 'Drs. H. Wawan Suwandi, M.Pd.', '196705151992031005', 'definitif'),
        ('20211518', '20211518', 'SMAN 1 BANJAR', 'Kota Banjar', 'Jl. K.H. Mustofa No. 1 Banjar', 'H. Agus Surtiawan, S.Pd., M.Pd.', '196811201994031004', 'definitif'),
        ('20211519', '20211519', 'SMAN 1 PANGANDARAN', 'Kabupaten Pangandaran', 'Jl. Babakan Pangandaran', 'Drs. H. Sukirman, M.Pd.', '196608101991031010', 'definitif')
      `);
      console.log("Seeded initial schools in MySQL.");
    }
    const [kopCount] = await p.query("SELECT COUNT(*) as count FROM `kop_settings`");
    if (kopCount[0].count === 0) {
      await p.query(`
        INSERT INTO \`kop_settings\` (id, logoType, row1, row2, row3, row4, row5, row6, tteTextJabatan1, tteTextJabatan2)
        VALUES ('default', 'svg-jabar', 'PEMERINTAH DAERAH PROVINSI JAWA BARAT', 'DINAS PENDIDIKAN', 'CABANG DINAS PENDIDIKAN WILAYAH XIII', 'Jalan Sukasenang No. 34 Telp./Fax (0265) 773123 Ciamis', 'e-mail: cabdinwil13@gmail.com', 'CIAMIS - 46211', 'KEPALA CABANG DINAS PENDIDIKAN WILAYAH XIII', 'DINAS PENDIDIKAN PROVINSI JAWA BARAT')
      `);
    }
    dbInitialized = true;
    console.log("MySQL sipak_guru_db auto-initialized successfully.");
    return true;
  } catch (err) {
    console.warn("Auto MySQL initialization skipped (MySQL might not be running yet):", err.message);
    return false;
  }
}
async function checkDbConnection() {
  try {
    const p = getDbPool();
    const [rows] = await p.query("SELECT 1 + 1 AS solution");
    const [tableRows] = await p.query(
      "SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = ?",
      [DB_CONFIG.database]
    );
    const tables = Array.isArray(tableRows) ? tableRows.map((r) => r.TABLE_NAME || r.table_name) : [];
    if (tables.length === 0) {
      await autoInitializeMysql();
    }
    return {
      connected: true,
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      database: DB_CONFIG.database,
      user: DB_CONFIG.user,
      message: "Koneksi ke MySQL database XAMPP berhasil terhubung dengan lancar.",
      tables,
      tablesCount: tables.length,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  } catch (error) {
    return {
      connected: false,
      host: DB_CONFIG.host,
      port: DB_CONFIG.port,
      database: DB_CONFIG.database,
      user: DB_CONFIG.user,
      message: `Belum terhubung ke MySQL XAMPP: ${error.message || error}. Pastikan modul MySQL di aplikasi XAMPP berstatus Running.`,
      tables: [],
      tablesCount: 0,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
}
function getDatabaseSqlContent() {
  try {
    const filePath = import_path.default.join(process.cwd(), "database.sql");
    if (import_fs.default.existsSync(filePath)) {
      return import_fs.default.readFileSync(filePath, "utf-8");
    }
  } catch (e) {
    console.error("Error reading database.sql:", e);
  }
  return "-- database.sql not found";
}

// src/server/fileDb.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var DATA_DIR = import_path2.default.join(process.cwd(), "data");
var DATA_FILE = import_path2.default.join(DATA_DIR, "sipak_db.json");
var DEFAULT_DATA = {
  schools: [
    {
      id: "20211516",
      npsn: "20211516",
      name: "SMAN 1 CIAMIS",
      city: "Kabupaten Ciamis",
      address: "Jl. Gunung Galunggung No. 37 Ciamis",
      principalName: "Drs. H. Suarman Marks, M.Pd.",
      principalNip: "196504121990031008",
      principalStatus: "definitif"
    },
    {
      id: "20211517",
      npsn: "20211517",
      name: "SMAN 2 CIAMIS",
      city: "Kabupaten Ciamis",
      address: "Jl. K.H. Ahmad Dahlan No. 2 Ciamis",
      principalName: "Drs. H. Wawan Suwandi, M.Pd.",
      principalNip: "196705151992031005",
      principalStatus: "definitif"
    },
    {
      id: "20211518",
      npsn: "20211518",
      name: "SMAN 1 BANJAR",
      city: "Kota Banjar",
      address: "Jl. K.H. Mustofa No. 1 Banjar",
      principalName: "H. Agus Surtiawan, S.Pd., M.Pd.",
      principalNip: "196811201994031004",
      principalStatus: "definitif"
    },
    {
      id: "20211519",
      npsn: "20211519",
      name: "SMAN 1 PANGANDARAN",
      city: "Kabupaten Pangandaran",
      address: "Jl. Babakan Pangandaran",
      principalName: "Drs. H. Sukirman, M.Pd.",
      principalNip: "196608101991031010",
      principalStatus: "definitif"
    }
  ],
  teachers: [],
  evaluations: [],
  users: [
    {
      username: "admin",
      password: "adminpaskonversi",
      role: "super_admin",
      school: "ALL",
      displayName: "Super Admin Dinas Pendidikan KCD XIII"
    },
    {
      username: "admin123",
      password: "admin123",
      role: "super_admin",
      school: "ALL",
      displayName: "Admin Utama"
    },
    {
      username: "sman2ciamis",
      password: "sman2ciamis123",
      role: "school_admin",
      school: "SMAN 2 CIAMIS",
      displayName: "Operator SMAN 2 Ciamis"
    },
    {
      username: "sman1ciamis",
      password: "sman1ciamis123",
      role: "school_admin",
      school: "SMAN 1 CIAMIS",
      displayName: "Operator SMAN 1 Ciamis"
    }
  ],
  kopSettings: {
    id: "default",
    logoType: "svg-jabar",
    customLogoUrl: "",
    row1: "PEMERINTAH DAERAH PROVINSI JAWA BARAT",
    row2: "DINAS PENDIDIKAN",
    row3: "CABANG DINAS PENDIDIKAN WILAYAH XIII",
    row4: "Jalan Sukasenang No. 34 Telp./Fax (0265) 773123 Ciamis",
    row5: "e-mail: cabdinwil13@gmail.com",
    row6: "CIAMIS - 46211",
    signatureType: "ttd_basah",
    ttdBasahType: "blank",
    tteLogoType: "default",
    tteTextHeader: "Ditandatangani secara elektronik oleh :",
    tteTextJabatan1: "KEPALA CABANG DINAS PENDIDIKAN WILAYAH XIII",
    tteTextJabatan2: "DINAS PENDIDIKAN PROVINSI JAWA BARAT"
  },
  logs: []
};
function ensureStorage() {
  try {
    if (!import_fs2.default.existsSync(DATA_DIR)) {
      import_fs2.default.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!import_fs2.default.existsSync(DATA_FILE)) {
      import_fs2.default.writeFileSync(DATA_FILE, JSON.stringify(DEFAULT_DATA, null, 2), "utf-8");
    }
  } catch (err) {
    console.error("Error ensuring storage directory:", err);
  }
}
function readLocalDb() {
  ensureStorage();
  try {
    const raw = import_fs2.default.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (e) {
    return DEFAULT_DATA;
  }
}
function writeLocalDb(data) {
  ensureStorage();
  try {
    import_fs2.default.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (e) {
    console.error("Error writing local database file:", e);
  }
}

// server.ts
var currentDir = typeof __dirname !== "undefined" ? __dirname : process.cwd();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = Number(process.env.PORT) || 3e3;
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ extended: true, limit: "50mb" }));
  autoInitializeMysql().catch((err) => {
    console.warn("MySQL auto-init notice:", err.message);
  });
  app.get("/api/health", (req, res) => {
    res.json({ status: "healthy", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/db-status", async (req, res) => {
    try {
      const status = await checkDbConnection();
      res.json(status);
    } catch (err) {
      res.json({
        connected: false,
        message: `Database status check failed: ${err.message || err}`,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  });
  app.get("/api/download-sql", (req, res) => {
    try {
      const sqlContent = getDatabaseSqlContent();
      res.setHeader("Content-Type", "application/sql");
      res.setHeader("Content-Disposition", 'attachment; filename="sipak_guru_db.sql"');
      res.send(sqlContent);
    } catch (err) {
      res.status(500).send(`Error downloading SQL file: ${err.message}`);
    }
  });
  app.post(["/api/login", "/api/mysql/login"], async (req, res) => {
    const { username, password } = req.body;
    const uName = (username || "").trim().toLowerCase();
    const pWord = (password || "").trim();
    if (!uName || !pWord) {
      return res.status(400).json({ error: "Username dan password harus diisi." });
    }
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query(
        "SELECT id, username, password, role, school, displayName FROM `app_users` WHERE LOWER(`username`) = ? LIMIT 1",
        [uName]
      );
      if (rows && rows.length > 0) {
        const u = rows[0];
        if (u.password === pWord) {
          return res.json({
            success: true,
            user: {
              username: u.username,
              displayName: u.displayName,
              role: u.role,
              school: u.school
            }
          });
        } else {
          return res.status(401).json({ error: "Kombinasi password yang dimasukkan salah!" });
        }
      }
    } catch (err) {
      console.warn("MySQL login query fallback to local store:", err);
    }
    const localDb = readLocalDb();
    const found = localDb.users.find(
      (u) => u.username.toLowerCase() === uName
    );
    if (found) {
      if (found.password === pWord) {
        return res.json({
          success: true,
          user: {
            username: found.username,
            displayName: found.displayName,
            role: found.role,
            school: found.school
          }
        });
      } else {
        return res.status(401).json({ error: "Kombinasi password yang dimasukkan salah!" });
      }
    }
    return res.status(404).json({ error: "Akun pengguna tidak ditemukan dalam database." });
  });
  app.get(["/api/teachers", "/api/mysql/teachers"], async (req, res) => {
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query("SELECT * FROM `teachers` ORDER BY `name` ASC");
      res.json(rows);
    } catch (err) {
      console.warn("Teachers GET fallback to local store:", err.message);
      const local = readLocalDb();
      res.json(local.teachers || []);
    }
  });
  app.post(["/api/teachers", "/api/mysql/teachers"], async (req, res) => {
    const t = req.body;
    if (!t.id || !t.name || !t.nip) {
      return res.status(400).json({ error: "ID, Nama, dan NIP guru wajib diisi." });
    }
    const local = readLocalDb();
    const existingIdx = local.teachers.findIndex((item) => item.id === t.id);
    if (existingIdx >= 0) {
      local.teachers[existingIdx] = { ...local.teachers[existingIdx], ...t };
    } else {
      local.teachers.push(t);
    }
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      const sql = `
        INSERT INTO \`teachers\` (
          id, name, nip, school, currentGolongan, targetGolongan,
          baseAK, akIntegrasi2022, akPendidikan, ratingSKP, workDurationYears,
          karpegNumber, birthPlaceDate, gender, tmtCurrentPangkat, tmtCurrentJabatan,
          unitKerja, instansiBiro, nomorSuratKonversi, nomorSuratAkumulasi, nomorSuratPenetapan,
          tempatDitetapkan, tanggalPenetapan, pejabatPenilaiTitle, pejabatPenilaiInstansi,
          pejabatPenilaiNama, pejabatPenilaiNip, pejabatPenilaiGolongan, pejabatPenilaiStatus,
          signatureType, ttdBasahType, ttdBasahImageUrl, ttdBasahImageBase64, ttdBasahHeight,
          tteLogoType, tteLogoUrl, tteLogoBase64, tteTextHeader, tteTextJabatan1, tteTextJabatan2,
          skPangkatFileLink, pakIntegrasiFileLink, ijazahFileLink, additionalFileLink, createdBy
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          name = VALUES(name), nip = VALUES(nip), school = VALUES(school),
          currentGolongan = VALUES(currentGolongan), targetGolongan = VALUES(targetGolongan),
          baseAK = VALUES(baseAK), akIntegrasi2022 = VALUES(akIntegrasi2022), akPendidikan = VALUES(akPendidikan),
          ratingSKP = VALUES(ratingSKP), workDurationYears = VALUES(workDurationYears),
          karpegNumber = VALUES(karpegNumber), birthPlaceDate = VALUES(birthPlaceDate), gender = VALUES(gender),
          tmtCurrentPangkat = VALUES(tmtCurrentPangkat), tmtCurrentJabatan = VALUES(tmtCurrentJabatan),
          unitKerja = VALUES(unitKerja), instansiBiro = VALUES(instansiBiro),
          nomorSuratKonversi = VALUES(nomorSuratKonversi), nomorSuratAkumulasi = VALUES(nomorSuratAkumulasi),
          nomorSuratPenetapan = VALUES(nomorSuratPenetapan), tempatDitetapkan = VALUES(tempatDitetapkan),
          tanggalPenetapan = VALUES(tanggalPenetapan), pejabatPenilaiTitle = VALUES(pejabatPenilaiTitle),
          pejabatPenilaiInstansi = VALUES(pejabatPenilaiInstansi), pejabatPenilaiNama = VALUES(pejabatPenilaiNama),
          pejabatPenilaiNip = VALUES(pejabatPenilaiNip), pejabatPenilaiGolongan = VALUES(pejabatPenilaiGolongan),
          pejabatPenilaiStatus = VALUES(pejabatPenilaiStatus), signatureType = VALUES(signatureType),
          ttdBasahType = VALUES(ttdBasahType), ttdBasahImageUrl = VALUES(ttdBasahImageUrl),
          ttdBasahImageBase64 = VALUES(ttdBasahImageBase64), ttdBasahHeight = VALUES(ttdBasahHeight),
          tteLogoType = VALUES(tteLogoType), tteLogoUrl = VALUES(tteLogoUrl), tteLogoBase64 = VALUES(tteLogoBase64),
          tteTextHeader = VALUES(tteTextHeader), tteTextJabatan1 = VALUES(tteTextJabatan1), tteTextJabatan2 = VALUES(tteTextJabatan2),
          skPangkatFileLink = VALUES(skPangkatFileLink), pakIntegrasiFileLink = VALUES(pakIntegrasiFileLink),
          ijazahFileLink = VALUES(ijazahFileLink), additionalFileLink = VALUES(additionalFileLink)
      `;
      const values = [
        t.id,
        t.name,
        t.nip,
        t.school || "",
        t.currentGolongan || "III/c",
        t.targetGolongan || "III/d",
        t.baseAK || 0,
        t.akIntegrasi2022 || 0,
        t.akPendidikan || 0,
        t.ratingSKP || "Baik",
        t.workDurationYears || 0,
        t.karpegNumber || null,
        t.birthPlaceDate || null,
        t.gender || "Laki-Laki",
        t.tmtCurrentPangkat || null,
        t.tmtCurrentJabatan || null,
        t.unitKerja || null,
        t.instansiBiro || null,
        t.nomorSuratKonversi || null,
        t.nomorSuratAkumulasi || null,
        t.nomorSuratPenetapan || null,
        t.tempatDitetapkan || null,
        t.tanggalPenetapan || null,
        t.pejabatPenilaiTitle || null,
        t.pejabatPenilaiInstansi || null,
        t.pejabatPenilaiNama || null,
        t.pejabatPenilaiNip || null,
        t.pejabatPenilaiGolongan || null,
        t.pejabatPenilaiStatus || "definitif",
        t.signatureType || "ttd_basah",
        t.ttdBasahType || "blank",
        t.ttdBasahImageUrl || null,
        t.ttdBasahImageBase64 || null,
        t.ttdBasahHeight || 64,
        t.tteLogoType || "default",
        t.tteLogoUrl || null,
        t.tteLogoBase64 || null,
        t.tteTextHeader || null,
        t.tteTextJabatan1 || null,
        t.tteTextJabatan2 || null,
        t.skPangkatFileLink || null,
        t.pakIntegrasiFileLink || null,
        t.ijazahFileLink || null,
        t.additionalFileLink || null,
        t.createdBy || "admin"
      ];
      await pool2.query(sql, values);
    } catch (err) {
      console.warn("MySQL write warning (saved to local backup):", err.message);
    }
    res.json({ success: true, id: t.id });
  });
  app.delete(["/api/teachers/:id", "/api/mysql/teachers/:id"], async (req, res) => {
    const id = req.params.id;
    const local = readLocalDb();
    local.teachers = local.teachers.filter((item) => item.id !== id);
    local.evaluations = local.evaluations.filter((ev) => ev.teacherId !== id);
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query("DELETE FROM `evaluations` WHERE `teacherId` = ?", [id]);
      await pool2.query("DELETE FROM `teachers` WHERE `id` = ?", [id]);
    } catch (err) {
      console.warn("MySQL delete warning:", err.message);
    }
    res.json({ success: true, id });
  });
  app.get(["/api/teachers/:id/evaluations", "/api/mysql/teachers/:id/evaluations"], async (req, res) => {
    const teacherId = req.params.id;
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query(
        "SELECT * FROM `evaluations` WHERE `teacherId` = ? ORDER BY `year` ASC",
        [teacherId]
      );
      const parsed = rows.map((r) => {
        if (typeof r.overrideData === "string") {
          try {
            r.overrideData = JSON.parse(r.overrideData);
          } catch (e) {
          }
        }
        return r;
      });
      res.json(parsed);
    } catch (err) {
      console.warn("Evaluations GET fallback to local store:", err.message);
      const local = readLocalDb();
      const evs = local.evaluations.filter((ev) => ev.teacherId === teacherId);
      res.json(evs);
    }
  });
  app.post(["/api/teachers/:id/evaluations", "/api/mysql/teachers/:id/evaluations"], async (req, res) => {
    const teacherId = req.params.id;
    const ev = req.body;
    if (!ev.id) {
      ev.id = `eval_${ev.year || 2024}_${Date.now()}`;
    }
    const local = readLocalDb();
    const idx = local.evaluations.findIndex((item) => item.id === ev.id);
    if (idx >= 0) {
      local.evaluations[idx] = { ...local.evaluations[idx], ...ev, teacherId };
    } else {
      local.evaluations.push({ ...ev, teacherId });
    }
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      const sql = `
        INSERT INTO \`evaluations\` (
          id, teacherId, year, period, rating, level, coefficient, multiplier,
          creditEarned, akPendidikan, notes, startDate, endDate, isCustomRange,
          customMonths, skpFileLink, evidenceFileLink, overrideData, createdBy
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          year = VALUES(year), period = VALUES(period), rating = VALUES(rating),
          level = VALUES(level), coefficient = VALUES(coefficient), multiplier = VALUES(multiplier),
          creditEarned = VALUES(creditEarned), akPendidikan = VALUES(akPendidikan), notes = VALUES(notes),
          startDate = VALUES(startDate), endDate = VALUES(endDate), isCustomRange = VALUES(isCustomRange),
          customMonths = VALUES(customMonths), skpFileLink = VALUES(skpFileLink), evidenceFileLink = VALUES(evidenceFileLink),
          overrideData = VALUES(overrideData)
      `;
      const overrideStr = ev.overrideData ? typeof ev.overrideData === "string" ? ev.overrideData : JSON.stringify(ev.overrideData) : null;
      const values = [
        ev.id,
        teacherId,
        ev.year,
        ev.period || "Tahunan",
        ev.rating || "Baik",
        ev.level || "Ahli Muda",
        ev.coefficient || 25,
        ev.multiplier || 1,
        ev.creditEarned || 25,
        ev.akPendidikan || 0,
        ev.notes || null,
        ev.startDate || null,
        ev.endDate || null,
        ev.isCustomRange ? 1 : 0,
        ev.customMonths || 12,
        ev.skpFileLink || null,
        ev.evidenceFileLink || null,
        overrideStr,
        ev.createdBy || "admin"
      ];
      await pool2.query(sql, values);
    } catch (err) {
      console.warn("MySQL eval write warning:", err.message);
    }
    res.json({ success: true, id: ev.id });
  });
  app.delete(["/api/evaluations/:id", "/api/mysql/evaluations/:id"], async (req, res) => {
    const id = req.params.id;
    const local = readLocalDb();
    local.evaluations = local.evaluations.filter((ev) => ev.id !== id);
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query("DELETE FROM `evaluations` WHERE `id` = ?", [id]);
    } catch (err) {
      console.warn("MySQL eval delete warning:", err.message);
    }
    res.json({ success: true, id });
  });
  app.get(["/api/schools", "/api/mysql/schools"], async (req, res) => {
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query("SELECT * FROM `schools` ORDER BY `name` ASC");
      res.json(rows);
    } catch (err) {
      console.warn("Schools GET fallback to local store:", err.message);
      const local = readLocalDb();
      res.json(local.schools || []);
    }
  });
  app.post(["/api/schools", "/api/mysql/schools"], async (req, res) => {
    const s = req.body;
    const schoolId = s.id || s.npsn;
    if (!schoolId || !s.name || !s.npsn) {
      return res.status(400).json({ error: "NPSN dan Nama Sekolah wajib diisi." });
    }
    const local = readLocalDb();
    const idx = local.schools.findIndex((item) => item.id === schoolId || item.npsn === s.npsn);
    if (idx >= 0) {
      local.schools[idx] = { ...local.schools[idx], ...s, id: schoolId };
    } else {
      local.schools.push({ ...s, id: schoolId });
    }
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      const sql = `
        INSERT INTO \`schools\` (id, npsn, name, city, address, principalName, principalNip, principalStatus)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          npsn = VALUES(npsn), name = VALUES(name), city = VALUES(city),
          address = VALUES(address), principalName = VALUES(principalName),
          principalNip = VALUES(principalNip), principalStatus = VALUES(principalStatus)
      `;
      await pool2.query(sql, [
        schoolId,
        s.npsn,
        s.name,
        s.city || null,
        s.address || null,
        s.principalName || null,
        s.principalNip || null,
        s.principalStatus || "definitif"
      ]);
    } catch (err) {
      console.warn("MySQL schools write warning:", err.message);
    }
    res.json({ success: true, id: schoolId });
  });
  app.delete(["/api/schools/:id", "/api/mysql/schools/:id"], async (req, res) => {
    const id = req.params.id;
    const local = readLocalDb();
    local.schools = local.schools.filter((s) => s.id !== id && s.npsn !== id);
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query("DELETE FROM `schools` WHERE `id` = ? OR `npsn` = ?", [id, id]);
    } catch (err) {
      console.warn("MySQL schools delete warning:", err.message);
    }
    res.json({ success: true, id });
  });
  app.get(["/api/users", "/api/mysql/users"], async (req, res) => {
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query("SELECT id, username, password, role, school, displayName, created_at, updated_at FROM `app_users` ORDER BY `displayName` ASC");
      res.json(rows);
    } catch (err) {
      console.warn("Users GET fallback to local store:", err.message);
      const local = readLocalDb();
      res.json(local.users || []);
    }
  });
  app.post(["/api/users", "/api/mysql/users"], async (req, res) => {
    const u = req.body;
    if (!u.username || !u.password) {
      return res.status(400).json({ error: "Username dan password wajib diisi." });
    }
    const local = readLocalDb();
    const idx = local.users.findIndex((item) => item.username.toLowerCase() === u.username.toLowerCase());
    if (idx >= 0) {
      local.users[idx] = { ...local.users[idx], ...u };
    } else {
      local.users.push(u);
    }
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      const sql = `
        INSERT INTO \`app_users\` (username, password, role, school, displayName)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          password = VALUES(password), role = VALUES(role),
          school = VALUES(school), displayName = VALUES(displayName)
      `;
      await pool2.query(sql, [u.username, u.password, u.role || "school_admin", u.school || "ALL", u.displayName || u.username]);
    } catch (err) {
      console.warn("MySQL users write warning:", err.message);
    }
    res.json({ success: true, username: u.username });
  });
  app.delete(["/api/users/:username", "/api/mysql/users/:username"], async (req, res) => {
    const username = req.params.username;
    const local = readLocalDb();
    local.users = local.users.filter((u) => u.username !== username);
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query("DELETE FROM `app_users` WHERE `username` = ?", [username]);
    } catch (err) {
      console.warn("MySQL users delete warning:", err.message);
    }
    res.json({ success: true, username });
  });
  app.get(["/api/settings/kop", "/api/mysql/settings/kop"], async (req, res) => {
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query("SELECT * FROM `kop_settings` WHERE `id` = 'default' LIMIT 1");
      if (rows && rows.length > 0) {
        return res.json(rows[0]);
      }
    } catch (err) {
      console.warn("Kop settings GET fallback to local store:", err.message);
    }
    const local = readLocalDb();
    res.json(local.kopSettings || null);
  });
  app.post(["/api/settings/kop", "/api/mysql/settings/kop"], async (req, res) => {
    const k = req.body;
    const local = readLocalDb();
    local.kopSettings = { ...local.kopSettings, ...k };
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      const sql = `
        INSERT INTO \`kop_settings\` (
          id, logoType, customLogoUrl, row1, row2, row3, row4, row5, row6,
          signatureType, ttdBasahType, ttdBasahImageUrl, ttdBasahImageBase64, ttdBasahHeight,
          tteLogoType, tteLogoUrl, tteLogoBase64, tteTextHeader, tteTextJabatan1, tteTextJabatan2,
          appLogoUrl
        ) VALUES ('default', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          logoType = VALUES(logoType), customLogoUrl = VALUES(customLogoUrl),
          row1 = VALUES(row1), row2 = VALUES(row2), row3 = VALUES(row3),
          row4 = VALUES(row4), row5 = VALUES(row5), row6 = VALUES(row6),
          signatureType = VALUES(signatureType), ttdBasahType = VALUES(ttdBasahType),
          ttdBasahImageUrl = VALUES(ttdBasahImageUrl), ttdBasahImageBase64 = VALUES(ttdBasahImageBase64),
          ttdBasahHeight = VALUES(ttdBasahHeight), tteLogoType = VALUES(tteLogoType),
          tteLogoUrl = VALUES(tteLogoUrl), tteLogoBase64 = VALUES(tteLogoBase64),
          tteTextHeader = VALUES(tteTextHeader), tteTextJabatan1 = VALUES(tteTextJabatan1),
          tteTextJabatan2 = VALUES(tteTextJabatan2),
          appLogoUrl = VALUES(appLogoUrl)
      `;
      await pool2.query(sql, [
        k.logoType || "svg-jabar",
        k.customLogoUrl || null,
        k.row1 || "",
        k.row2 || "",
        k.row3 || "",
        k.row4 || "",
        k.row5 || "",
        k.row6 || "",
        k.signatureType || "ttd_basah",
        k.ttdBasahType || "blank",
        k.ttdBasahImageUrl || null,
        k.ttdBasahImageBase64 || null,
        k.ttdBasahHeight || 64,
        k.tteLogoType || "default",
        k.tteLogoUrl || null,
        k.tteLogoBase64 || null,
        k.tteTextHeader || null,
        k.tteTextJabatan1 || null,
        k.tteTextJabatan2 || null,
        k.appLogoUrl || null
      ]);
    } catch (err) {
      console.warn("MySQL kop write warning:", err.message);
    }
    res.json({ success: true });
  });
  app.get(["/api/logs", "/api/mysql/logs"], async (req, res) => {
    try {
      const pool2 = getDbPool();
      const [rows] = await pool2.query("SELECT * FROM `system_logs` ORDER BY `timestamp` DESC LIMIT 200");
      res.json(rows);
    } catch (err) {
      const local = readLocalDb();
      res.json(local.logs || []);
    }
  });
  app.post(["/api/logs", "/api/mysql/logs"], async (req, res) => {
    const l = req.body;
    const logItem = {
      id: l.id || Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
      timestamp: l.timestamp || (/* @__PURE__ */ new Date()).toISOString(),
      error: l.error || "Unknown event",
      operationType: l.operationType || "general",
      path: l.path || null,
      userId: l.userId || null,
      email: l.email || null,
      browser: l.browser || null,
      severity: l.severity || "info",
      resolved: l.resolved ? 1 : 0,
      resolutionNotes: l.resolutionNotes || null
    };
    const local = readLocalDb();
    local.logs.unshift(logItem);
    if (local.logs.length > 200) local.logs = local.logs.slice(0, 200);
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query(`
        INSERT INTO \`system_logs\` (id, timestamp, error, operationType, path, userId, email, browser, severity, resolved, resolutionNotes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        logItem.id,
        logItem.timestamp,
        logItem.error,
        logItem.operationType,
        logItem.path,
        logItem.userId,
        logItem.email,
        logItem.browser,
        logItem.severity,
        logItem.resolved,
        logItem.resolutionNotes
      ]);
    } catch (err) {
    }
    res.json({ success: true, id: logItem.id });
  });
  app.delete(["/api/logs", "/api/mysql/logs"], async (req, res) => {
    const local = readLocalDb();
    local.logs = [];
    writeLocalDb(local);
    try {
      const pool2 = getDbPool();
      await pool2.query("TRUNCATE TABLE `system_logs`");
    } catch (err) {
    }
    res.json({ success: true });
  });
  app.get(["/api/backup/export", "/api/mysql/export"], async (req, res) => {
    try {
      const local = readLocalDb();
      let schools = local.schools;
      let teachers = local.teachers;
      let evaluations = local.evaluations;
      let users = local.users;
      let kopSettings = local.kopSettings;
      try {
        const pool2 = getDbPool();
        const [scRows] = await pool2.query("SELECT * FROM `schools`");
        const [tcRows] = await pool2.query("SELECT * FROM `teachers`");
        const [evRows] = await pool2.query("SELECT * FROM `evaluations`");
        const [usRows] = await pool2.query("SELECT id, username, password, role, school, displayName FROM `app_users`");
        const [kpRows] = await pool2.query("SELECT * FROM `kop_settings` WHERE `id` = 'default'");
        if (scRows.length > 0) schools = scRows;
        if (tcRows.length > 0) teachers = tcRows;
        if (evRows.length > 0) evaluations = evRows;
        if (usRows.length > 0) users = usRows;
        if (kpRows.length > 0) kopSettings = kpRows[0];
      } catch (err) {
      }
      res.json({
        version: "sipak_v2_mysql",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        exportedBy: "admin",
        schools,
        teachers: teachers.map((t) => ({
          ...t,
          evaluations: evaluations.filter((e) => e.teacherId === t.id)
        })),
        app_users: users,
        kopSettings
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post(["/api/mysql/sync-batch", "/api/backup/import"], async (req, res) => {
    try {
      const { schools, teachers, users, app_users, kopSettings } = req.body;
      const userList = users || app_users || [];
      const local = readLocalDb();
      if (Array.isArray(schools)) local.schools = schools;
      if (Array.isArray(teachers)) local.teachers = teachers;
      if (Array.isArray(userList)) local.users = userList;
      if (kopSettings) local.kopSettings = kopSettings;
      writeLocalDb(local);
      let schoolsCount = 0;
      let teachersCount = 0;
      let usersCount = 0;
      try {
        const pool2 = getDbPool();
        if (Array.isArray(schools)) {
          for (const s of schools) {
            const sId = s.id || s.npsn;
            if (sId && s.npsn && s.name) {
              await pool2.query(`
                INSERT INTO \`schools\` (id, npsn, name, city, address, principalName, principalNip, principalStatus)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                  npsn = VALUES(npsn), name = VALUES(name), city = VALUES(city),
                  address = VALUES(address), principalName = VALUES(principalName),
                  principalNip = VALUES(principalNip), principalStatus = VALUES(principalStatus)
              `, [
                sId,
                s.npsn,
                s.name,
                s.city || null,
                s.address || null,
                s.principalName || null,
                s.principalNip || null,
                s.principalStatus || "definitif"
              ]);
              schoolsCount++;
            }
          }
        }
        if (Array.isArray(teachers)) {
          for (const t of teachers) {
            if (t.id && t.name && t.nip) {
              const sql = `
                INSERT INTO \`teachers\` (
                  id, name, nip, school, currentGolongan, targetGolongan,
                  baseAK, akIntegrasi2022, akPendidikan, ratingSKP, workDurationYears,
                  karpegNumber, birthPlaceDate, gender, tmtCurrentPangkat, tmtCurrentJabatan,
                  unitKerja, instansiBiro, nomorSuratKonversi, nomorSuratAkumulasi, nomorSuratPenetapan,
                  tempatDitetapkan, tanggalPenetapan, pejabatPenilaiTitle, pejabatPenilaiInstansi,
                  pejabatPenilaiNama, pejabatPenilaiNip, pejabatPenilaiGolongan, pejabatPenilaiStatus,
                  signatureType, ttdBasahType, ttdBasahImageUrl, ttdBasahImageBase64, ttdBasahHeight,
                  tteLogoType, tteLogoUrl, tteLogoBase64, tteTextHeader, tteTextJabatan1, tteTextJabatan2,
                  skPangkatFileLink, pakIntegrasiFileLink, ijazahFileLink, additionalFileLink, createdBy
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                  name = VALUES(name), nip = VALUES(nip), school = VALUES(school),
                  currentGolongan = VALUES(currentGolongan), targetGolongan = VALUES(targetGolongan),
                  baseAK = VALUES(baseAK), akIntegrasi2022 = VALUES(akIntegrasi2022), akPendidikan = VALUES(akPendidikan),
                  ratingSKP = VALUES(ratingSKP), workDurationYears = VALUES(workDurationYears),
                  karpegNumber = VALUES(karpegNumber), birthPlaceDate = VALUES(birthPlaceDate), gender = VALUES(gender),
                  tmtCurrentPangkat = VALUES(tmtCurrentPangkat), tmtCurrentJabatan = VALUES(tmtCurrentJabatan),
                  unitKerja = VALUES(unitKerja), instansiBiro = VALUES(instansiBiro),
                  nomorSuratKonversi = VALUES(nomorSuratKonversi), nomorSuratAkumulasi = VALUES(nomorSuratAkumulasi),
                  nomorSuratPenetapan = VALUES(nomorSuratPenetapan), tempatDitetapkan = VALUES(tempatDitetapkan),
                  tanggalPenetapan = VALUES(tanggalPenetapan), pejabatPenilaiTitle = VALUES(pejabatPenilaiTitle),
                  pejabatPenilaiInstansi = VALUES(pejabatPenilaiInstansi), pejabatPenilaiNama = VALUES(pejabatPenilaiNama),
                  pejabatPenilaiNip = VALUES(pejabatPenilaiNip), pejabatPenilaiGolongan = VALUES(pejabatPenilaiGolongan),
                  pejabatPenilaiStatus = VALUES(pejabatPenilaiStatus), signatureType = VALUES(signatureType),
                  ttdBasahType = VALUES(ttdBasahType), ttdBasahImageUrl = VALUES(ttdBasahImageUrl),
                  ttdBasahImageBase64 = VALUES(ttdBasahImageBase64), ttdBasahHeight = VALUES(ttdBasahHeight),
                  tteLogoType = VALUES(tteLogoType), tteLogoUrl = VALUES(tteLogoUrl), tteLogoBase64 = VALUES(tteLogoBase64),
                  tteTextHeader = VALUES(tteTextHeader), tteTextJabatan1 = VALUES(tteTextJabatan1), tteTextJabatan2 = VALUES(tteTextJabatan2),
                  skPangkatFileLink = VALUES(skPangkatFileLink), pakIntegrasiFileLink = VALUES(pakIntegrasiFileLink),
                  ijazahFileLink = VALUES(ijazahFileLink), additionalFileLink = VALUES(additionalFileLink)
              `;
              const values = [
                t.id,
                t.name,
                t.nip,
                t.school || "",
                t.currentGolongan || "III/c",
                t.targetGolongan || "III/d",
                t.baseAK || 0,
                t.akIntegrasi2022 || 0,
                t.akPendidikan || 0,
                t.ratingSKP || "Baik",
                t.workDurationYears || 0,
                t.karpegNumber || null,
                t.birthPlaceDate || null,
                t.gender || "Laki-Laki",
                t.tmtCurrentPangkat || null,
                t.tmtCurrentJabatan || null,
                t.unitKerja || null,
                t.instansiBiro || null,
                t.nomorSuratKonversi || null,
                t.nomorSuratAkumulasi || null,
                t.nomorSuratPenetapan || null,
                t.tempatDitetapkan || null,
                t.tanggalPenetapan || null,
                t.pejabatPenilaiTitle || null,
                t.pejabatPenilaiInstansi || null,
                t.pejabatPenilaiNama || null,
                t.pejabatPenilaiNip || null,
                t.pejabatPenilaiGolongan || null,
                t.pejabatPenilaiStatus || "definitif",
                t.signatureType || "ttd_basah",
                t.ttdBasahType || "blank",
                t.ttdBasahImageUrl || null,
                t.ttdBasahImageBase64 || null,
                t.ttdBasahHeight || 64,
                t.tteLogoType || "default",
                t.tteLogoUrl || null,
                t.tteLogoBase64 || null,
                t.tteTextHeader || null,
                t.tteTextJabatan1 || null,
                t.tteTextJabatan2 || null,
                t.skPangkatFileLink || null,
                t.pakIntegrasiFileLink || null,
                t.ijazahFileLink || null,
                t.additionalFileLink || null,
                t.createdBy || "admin"
              ];
              await pool2.query(sql, values);
              teachersCount++;
            }
          }
        }
        if (Array.isArray(userList)) {
          for (const u of userList) {
            if (u.username && u.password) {
              await pool2.query(`
                INSERT INTO \`app_users\` (username, password, role, school, displayName)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                  password = VALUES(password), role = VALUES(role),
                  school = VALUES(school), displayName = VALUES(displayName)
              `, [u.username, u.password, u.role || "school_admin", u.school || "ALL", u.displayName || u.username]);
              usersCount++;
            }
          }
        }
      } catch (err) {
        console.warn("MySQL sync batch warning:", err.message);
      }
      res.json({ success: true, synced: { schoolsCount, teachersCount, usersCount } });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  const isDev = process.env.NODE_ENV !== "production";
  if (isDev) {
    try {
      const vite = await (0, import_vite.createServer)({
        server: {
          middlewareMode: true,
          hmr: false,
          watch: {
            ignored: [
              "**/data/**",
              "**/dist/**",
              "**/.git/**",
              "**/*.sql",
              "**/*.log"
            ]
          }
        },
        appType: "spa"
      });
      app.use(vite.middlewares);
      console.log("Vite development middleware loaded.");
    } catch (viteErr) {
      console.warn("Vite dev middleware initialization error, serving static assets:", viteErr?.message || viteErr);
      serveStaticAssets(app);
    }
  } else {
    serveStaticAssets(app);
  }
  if (isDev) {
    const devPort = 3e3;
    app.listen(devPort, "0.0.0.0", () => {
      console.log(`SIPAK-GURU Dev Server running on http://0.0.0.0:${devPort}`);
    });
  } else {
    if (typeof global.PhusionPassenger !== "undefined") {
      app.listen("passenger");
      console.log("SIPAK-GURU Server running under Phusion Passenger / LiteSpeed (socket: passenger)");
    } else {
      const port = process.env.PORT || 3e3;
      app.listen(port, () => {
        console.log(`SIPAK-GURU Server running on port/socket: ${port}`);
      });
    }
  }
}
function serveStaticAssets(app) {
  let distPath = import_path3.default.join(process.cwd(), "dist");
  if (import_fs3.default.existsSync(import_path3.default.join(currentDir, "index.html")) && currentDir !== process.cwd()) {
    distPath = currentDir;
  } else if (import_fs3.default.existsSync(import_path3.default.join(process.cwd(), "dist", "index.html"))) {
    distPath = import_path3.default.join(process.cwd(), "dist");
  } else if (import_fs3.default.existsSync(import_path3.default.join(currentDir, "../dist", "index.html"))) {
    distPath = import_path3.default.resolve(currentDir, "../dist");
  }
  app.use(import_express.default.static(distPath, {
    setHeaders: (res) => {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    }
  }));
  app.get("*", (req, res) => {
    const indexPath = import_path3.default.join(distPath, "index.html");
    if (import_fs3.default.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).send("SIPAK-GURU Application: dist/index.html not found. Please run 'npm run build'.");
    }
  });
  console.log(`Serving compiled production static assets from ${distPath} with CORS enabled.`);
}
startServer().catch((err) => {
  console.error("Critical server startup crash:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
